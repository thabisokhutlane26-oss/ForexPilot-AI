# ForexPilot AI — Android Java

A Java Android Forex signal dashboard using Twelve Data live WebSocket prices plus historical candles for technical signal calculation.

## What it does
- Real-time price stream via Twelve Data WebSocket.
- Dynamic Forex market status using `America/New_York` and daylight-saving-aware `java.time`.
- Daily FX break handling: 16:59–17:05 New York time.
- Sunday open: 17:05 New York time; Friday weekly close: 16:59 New York time.
- Sydney, Tokyo, London and New York session detection.
- M1/M5/M15/M30/H1/H4 candle timeframes.
- EMA20/EMA50, RSI14, MACD and ATR-based signal calculation.
- BUY/SELL/WAIT with entry, stop-loss and three take-profit levels.
- Stale-data warning when the live tick stream stops updating.
- No real-money order execution in this version.

The market-hour schedule follows a broker-style FX schedule; exact hours can differ by broker and instrument. The app uses New York time to avoid hard-coded UTC offsets.

## Twelve Data API key
1. Create a Twelve Data account and obtain your API key.
2. For local builds, put the key in `gradle.properties`:
   `TWELVE_DATA_API_KEY=YOUR_KEY`
3. For GitHub Actions, add a repository secret named `TWELVE_DATA_API_KEY`.
4. Run the workflow. The APK is uploaded as `ForexPilot-AI-debug-apk`.

Do not commit a real API key to a public repository. A key embedded in an Android APK can ultimately be extracted; for a production public app, move the market-data connection behind your own backend.

## Build
The project uses Android Gradle Plugin 9.4.0, Gradle 9.6 and JDK 17.

GitHub Actions uses the installed Gradle command so the repository does not depend on a checked-in Gradle wrapper JAR.

## Important
This is a signal application, not a guaranteed-profit robot. It does not automatically place trades. Before any future broker/MT5 execution feature is added, test it with a demo account and add explicit risk controls.
