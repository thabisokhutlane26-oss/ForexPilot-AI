package com.forexpilot.ai;

public final class Candle {
    public final long epochSeconds;
    public final double open, high, low, close;
    public Candle(long epochSeconds, double open, double high, double low, double close) {
        this.epochSeconds = epochSeconds;
        this.open = open; this.high = high; this.low = low; this.close = close;
    }
}
