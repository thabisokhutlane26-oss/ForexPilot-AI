package com.forexpilot.ai;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.time.Duration;
import java.time.ZonedDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final String[] PAIRS = {"EUR/USD","GBP/USD","USD/JPY","USD/CHF","AUD/USD","USD/CAD","NZD/USD","XAU/USD"};
    private static final String[] TIMEFRAMES = {"1min","5min","15min","30min","1h","4h"};
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("dd MMM yyyy HH:mm:ss z", Locale.US);

    private TextView marketStatus, session, marketCountdown, dataStatus, pairPrice, lastUpdate;
    private TextView signal, signalReason, entry, sl, tp1, tp2, tp3, confidence, generated;
    private Spinner pairSpinner, timeframeSpinner;
    private final Handler handler = new Handler();
    private TwelveDataClient client;
    private String selectedPair = PAIRS[0];
    private String selectedTimeframe = TIMEFRAMES[2];
    private double latestPrice = Double.NaN;
    private long lastTickMs = 0L;
    private boolean streamConnected = false;

    private final Runnable clockTask = new Runnable() {
        @Override public void run() {
            updateClock();
            handler.postDelayed(this, 1000);
        }
    };
    private final Runnable candleTask = new Runnable() {
        @Override public void run() {
            refreshSignal();
            handler.postDelayed(this, 60000);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        setupSpinners();
        client = new TwelveDataClient(BuildConfig.TWELVE_DATA_API_KEY);
        if (!client.hasApiKey()) {
            dataStatus.setText("Data: API KEY REQUIRED");
            dataStatus.setTextColor(Color.rgb(255,179,0));
        } else {
            connectLiveStream();
            refreshSignal();
        }
        handler.post(clockTask);
    }

    private void bindViews() {
        marketStatus=findViewById(R.id.marketStatus); session=findViewById(R.id.session); marketCountdown=findViewById(R.id.marketCountdown); dataStatus=findViewById(R.id.dataStatus);
        pairPrice=findViewById(R.id.pairPrice); lastUpdate=findViewById(R.id.lastUpdate); signal=findViewById(R.id.signal); signalReason=findViewById(R.id.signalReason);
        entry=findViewById(R.id.entry); sl=findViewById(R.id.sl); tp1=findViewById(R.id.tp1); tp2=findViewById(R.id.tp2); tp3=findViewById(R.id.tp3); confidence=findViewById(R.id.confidence); generated=findViewById(R.id.generated);
        pairSpinner=findViewById(R.id.pairSpinner); timeframeSpinner=findViewById(R.id.timeframeSpinner);
    }

    private void setupSpinners() {
        ArrayAdapter<String> pairs = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Arrays.asList(PAIRS));
        ArrayAdapter<String> frames = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Arrays.asList(TIMEFRAMES));
        pairSpinner.setAdapter(pairs); timeframeSpinner.setAdapter(frames);
        pairSpinner.setOnItemSelectedListener(new SimpleItemListener() { @Override public void selected(int position) { selectedPair=PAIRS[position]; latestPrice=Double.NaN; refreshSignal(); } });
        timeframeSpinner.setOnItemSelectedListener(new SimpleItemListener() { @Override public void selected(int position) { selectedTimeframe=TIMEFRAMES[position]; refreshSignal(); } });
    }

    private void connectLiveStream() {
        client.connectPrices(String.join(",", PAIRS), new TwelveDataClient.PriceListener() {
            @Override public void onPrice(String symbol, double price, long timestampMs) {
                if (symbol.equalsIgnoreCase(selectedPair)) {
                    latestPrice=price; lastTickMs=timestampMs;
                    pairPrice.setText(selectedPair + "  " + formatPrice(price));
                    lastUpdate.setText("Last tick: " + formatTime(timestampMs));
                    if (streamConnected) dataStatus.setText("Data: LIVE • streaming");
                }
            }
            @Override public void onConnection(boolean connected, String message) {
                streamConnected=connected;
                dataStatus.setText("Data: " + message);
                dataStatus.setTextColor(connected ? Color.rgb(0,200,83) : Color.rgb(255,82,82));
            }
        });
    }

    private void refreshSignal() {
        if (!MarketClock.isForexOpen(ZonedDateTime.now(ZoneId.of("America/New_York")))) {
            showWait("MARKET CLOSED", "Signals paused until the next forex opening window.");
            return;
        }
        if (!client.hasApiKey()) return;
        dataStatus.setText("Data: loading candles...");
        client.loadCandles(selectedPair, selectedTimeframe, 120, new TwelveDataClient.CandleListener() {
            @Override public void onCandles(List<Candle> candles) {
                try {
                    SignalResult r=SignalEngine.analyze(candles);
                    renderSignal(r);
                    dataStatus.setText(streamConnected ? "Data: LIVE • candles refreshed" : "Data: candle API only");
                } catch(Exception e) { showWait("WAIT", "Signal engine error: " + e.getMessage()); }
            }
            @Override public void onError(String message) { dataStatus.setText("Data error: " + message); showWait("WAIT", "Waiting for valid market data."); }
        });
    }

    private void renderSignal(SignalResult r) {
        signal.setText(r.direction);
        if ("BUY".equals(r.direction)) signal.setTextColor(Color.rgb(0,200,83));
        else if ("SELL".equals(r.direction)) signal.setTextColor(Color.rgb(255,82,82));
        else signal.setTextColor(Color.rgb(255,179,0));
        signalReason.setText(r.reason);
        if ("WAIT".equals(r.direction)) {
            entry.setText("Entry: " + formatPrice(r.entry)); sl.setText("Stop Loss: --"); tp1.setText("Take Profit 1: --"); tp2.setText("Take Profit 2: --"); tp3.setText("Take Profit 3: --");
        } else {
            entry.setText("Entry: " + formatPrice(r.entry)); sl.setText("Stop Loss: " + formatPrice(r.sl)); tp1.setText("Take Profit 1: " + formatPrice(r.tp1)); tp2.setText("Take Profit 2: " + formatPrice(r.tp2)); tp3.setText("Take Profit 3: " + formatPrice(r.tp3));
        }
        confidence.setText("Confidence: " + r.confidence + "%");
        generated.setText("Generated: " + formatTime(r.generatedAt));
    }

    private void showWait(String title, String reason) {
        signal.setText(title); signal.setTextColor(Color.rgb(255,179,0)); signalReason.setText(reason);
        entry.setText("Entry: --"); sl.setText("Stop Loss: --"); tp1.setText("Take Profit 1: --"); tp2.setText("Take Profit 2: --"); tp3.setText("Take Profit 3: --"); confidence.setText("Confidence: --"); generated.setText("Generated: --");
    }

    private void updateClock() {
        ZonedDateTime now=ZonedDateTime.now(ZoneId.of("America/New_York"));
        boolean open=MarketClock.isForexOpen(now);
        marketStatus.setText(open ? "● FOREX MARKET OPEN" : "● FOREX MARKET CLOSED");
        marketStatus.setTextColor(open ? Color.rgb(0,200,83) : Color.rgb(255,82,82));
        session.setText("Session: " + MarketClock.session(now));
        ZonedDateTime target=open ? MarketClock.nextClose(now) : MarketClock.nextOpen(now);
        long seconds=Math.max(0, Duration.between(now, target).getSeconds());
        marketCountdown.setText((open ? "Closes in " : "Opens in ") + humanDuration(seconds) + " • New York: " + now.format(DateTimeFormatter.ofPattern("HH:mm:ss")));
        if (!open && !signal.getText().toString().equals("MARKET CLOSED")) showWait("MARKET CLOSED", "Signals paused until the next forex opening window.");
        if (open && signal.getText().toString().equals("MARKET CLOSED")) refreshSignal();
        if (lastTickMs > 0 && System.currentTimeMillis()-lastTickMs > 30000) {
            dataStatus.setText("Data: STALE • last tick " + ((System.currentTimeMillis()-lastTickMs)/1000) + "s ago");
            dataStatus.setTextColor(Color.rgb(255,179,0));
        }
    }

    private String humanDuration(long s) { long h=s/3600, m=(s%3600)/60, sec=s%60; return String.format(Locale.US,"%02dh %02dm %02ds",h,m,sec); }
    private String formatTime(long ms) { return java.time.Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(TIME_FMT); }
    private String formatPrice(double p) { if(Double.isNaN(p)) return "--"; int decimals=selectedPair.endsWith("JPY")?3:(selectedPair.equals("XAU/USD")?2:5); return String.format(Locale.US,"%."+decimals+"f",p); }

    @Override protected void onDestroy() { handler.removeCallbacksAndMessages(null); if(client!=null) client.close(); super.onDestroy(); }

    private abstract static class SimpleItemListener implements android.widget.AdapterView.OnItemSelectedListener {
        public abstract void selected(int position);
        @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { selected(position); }
        @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
    }
}
