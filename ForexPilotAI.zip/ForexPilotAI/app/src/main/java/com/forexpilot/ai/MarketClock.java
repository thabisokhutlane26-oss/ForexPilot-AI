package com.forexpilot.ai;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public final class MarketClock {
    private static final ZoneId NY = ZoneId.of("America/New_York");
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("EEE HH:mm:ss z", Locale.US);

    private MarketClock() {}

    public static boolean isForexOpen(ZonedDateTime now) {
        ZonedDateTime n = now.withZoneSameInstant(NY);
        DayOfWeek d = n.getDayOfWeek();
        int m = n.getHour() * 60 + n.getMinute();
        if (d == DayOfWeek.SATURDAY) return false;
        if (d == DayOfWeek.SUNDAY) return m >= 17 * 60 + 5;
        if (d == DayOfWeek.FRIDAY) return m < 16 * 60 + 59;
        return !(m >= 16 * 60 + 59 && m < 17 * 60 + 5);
    }

    public static String statusDetail(ZonedDateTime now) {
        ZonedDateTime n = now.withZoneSameInstant(NY);
        if (isForexOpen(n)) return "Open until " + nextClose(n).format(FMT);
        return "Opens " + nextOpen(n).format(FMT);
    }

    public static ZonedDateTime nextOpen(ZonedDateTime now) {
        ZonedDateTime n = now.withZoneSameInstant(NY);
        for (int i = 0; i < 8; i++) {
            ZonedDateTime candidate = n.toLocalDate().plusDays(i).atTime(17, 5).atZone(NY);
            if (candidate.isAfter(n) && (candidate.getDayOfWeek() == DayOfWeek.SUNDAY ||
                    (candidate.getDayOfWeek().getValue() >= 1 && candidate.getDayOfWeek().getValue() <= 4))) return candidate;
        }
        return n.plusDays(1).withHour(17).withMinute(5).withSecond(0).withNano(0);
    }

    public static ZonedDateTime nextClose(ZonedDateTime now) {
        ZonedDateTime n = now.withZoneSameInstant(NY);
        ZonedDateTime todayClose = n.toLocalDate().atTime(16, 59).atZone(NY);
        if (n.isBefore(todayClose) && n.getDayOfWeek() != DayOfWeek.SATURDAY && n.getDayOfWeek() != DayOfWeek.SUNDAY) return todayClose;
        LocalDate d = n.toLocalDate();
        do { d = d.plusDays(1); } while (d.getDayOfWeek() == DayOfWeek.SATURDAY || d.getDayOfWeek() == DayOfWeek.SUNDAY);
        return d.atTime(16, 59).atZone(NY);
    }

    public static String session(ZonedDateTime now) {
        ZonedDateTime utc = now.withZoneSameInstant(ZoneOffset.UTC);
        ZonedDateTime ny = now.withZoneSameInstant(NY);
        ZonedDateTime london = now.withZoneSameInstant(ZoneId.of("Europe/London"));
        ZonedDateTime tokyo = now.withZoneSameInstant(ZoneId.of("Asia/Tokyo"));
        ZonedDateTime sydney = now.withZoneSameInstant(ZoneId.of("Australia/Sydney"));
        boolean nyOpen = ny.getHour() >= 8 && ny.getHour() < 17;
        boolean londonOpen = london.getHour() >= 8 && london.getHour() < 17;
        boolean tokyoOpen = tokyo.getHour() >= 9 && tokyo.getHour() < 18;
        boolean sydneyOpen = sydney.getHour() >= 8 && sydney.getHour() < 17;
        if (nyOpen && londonOpen) return "NEW YORK / LONDON OVERLAP";
        if (nyOpen) return "NEW YORK";
        if (londonOpen) return "LONDON";
        if (tokyoOpen) return "TOKYO";
        if (sydneyOpen) return "SYDNEY";
        return "BETWEEN SESSIONS";
    }

    public static long secondsUntil(ZonedDateTime target, ZonedDateTime now) {
        return Math.max(0, Duration.between(now, target).getSeconds());
    }
}
