package com.forexpilot.ai;

import java.util.*;

public final class SignalEngine {
    private SignalEngine() {}

    public static SignalResult analyze(List<Candle> candles) {
        if (candles == null || candles.size() < 60) throw new IllegalArgumentException("Not enough candles");
        double[] closes = new double[candles.size()];
        for (int i=0;i<candles.size();i++) closes[i]=candles.get(i).close;
        double ema20 = ema(closes,20), ema50=ema(closes,50), rsi=rsi(closes,14);
        double[] macd = macd(closes);
        double atr = atr(candles,14);
        double entry = closes[closes.length-1];
        int bull=0,bear=0;
        if (ema20 > ema50) bull++; else bear++;
        if (entry > ema20) bull++; else bear++;
        if (rsi >= 52 && rsi <= 70) bull++; else if (rsi <= 48 && rsi >= 30) bear++;
        if (macd[0] > macd[1]) bull++; else bear++;
        if (bull >= 3 && bull > bear) {
            double sl=entry-1.5*atr, tp1=entry+1.0*atr, tp2=entry+2.0*atr, tp3=entry+3.0*atr;
            return new SignalResult("BUY", String.format(Locale.US,"EMA20 %.5f > EMA50 %.5f | RSI %.1f | MACD bullish",ema20,ema50,rsi),entry,sl,tp1,tp2,tp3,Math.min(95,55+10*(bull-bear)),System.currentTimeMillis());
        }
        if (bear >= 3 && bear > bull) {
            double sl=entry+1.5*atr, tp1=entry-1.0*atr, tp2=entry-2.0*atr, tp3=entry-3.0*atr;
            return new SignalResult("SELL", String.format(Locale.US,"EMA20 %.5f < EMA50 %.5f | RSI %.1f | MACD bearish",ema20,ema50,rsi),entry,sl,tp1,tp2,tp3,Math.min(95,55+10*(bear-bull)),System.currentTimeMillis());
        }
        return new SignalResult("WAIT", String.format(Locale.US,"Mixed confirmation | EMA20 %.5f | EMA50 %.5f | RSI %.1f",ema20,ema50,rsi),entry,0,0,0,0,50,System.currentTimeMillis());
    }

    private static double ema(double[] a,int p){ double k=2.0/(p+1),e=a[0]; for(int i=1;i<a.length;i++) e=a[i]*k+e*(1-k); return e; }
    private static double rsi(double[] a,int p){ if(a.length<=p)return 50; double g=0,l=0; for(int i=a.length-p;i<a.length;i++){double d=a[i]-a[i-1];if(d>0)g+=d;else l-=d;} if(l==0)return 100; return 100-(100/(1+g/l)); }
    private static double[] macd(double[] a){ double e12=ema(a,12),e26=ema(a,26); double m=e12-e26; double[] ms=new double[Math.max(1,a.length-25)]; for(int i=25;i<a.length;i++){double[] x=Arrays.copyOfRange(a,0,i+1);ms[i-25]=ema(x,12)-ema(x,26);} double signal=ema(ms,9); return new double[]{m,signal}; }
    private static double atr(List<Candle> c,int p){ if(c.size()<p+1)return 0.001; double sum=0; int start=c.size()-p; for(int i=start;i<c.size();i++){Candle x=c.get(i),prev=c.get(i-1); sum+=Math.max(x.high-x.low,Math.max(Math.abs(x.high-prev.close),Math.abs(x.low-prev.close)));} return Math.max(sum/p,0.00001); }
}
