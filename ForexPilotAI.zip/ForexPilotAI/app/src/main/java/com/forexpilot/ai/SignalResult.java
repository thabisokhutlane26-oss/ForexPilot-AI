package com.forexpilot.ai;

public final class SignalResult {
    public final String direction, reason;
    public final double entry, sl, tp1, tp2, tp3;
    public final int confidence;
    public final long generatedAt;
    public SignalResult(String direction, String reason, double entry, double sl, double tp1, double tp2, double tp3, int confidence, long generatedAt) {
        this.direction=direction; this.reason=reason; this.entry=entry; this.sl=sl; this.tp1=tp1; this.tp2=tp2; this.tp3=tp3; this.confidence=confidence; this.generatedAt=generatedAt;
    }
}
