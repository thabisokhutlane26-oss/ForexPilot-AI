package com.forexpilot.ai;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

public final class TwelveDataClient {
    public interface PriceListener { void onPrice(String symbol, double price, long timestampMs); void onConnection(boolean connected, String message); }
    public interface CandleListener { void onCandles(List<Candle> candles); void onError(String message); }

    private final OkHttpClient http;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final String apiKey;
    private WebSocket webSocket;
    private boolean manuallyClosed;
    private int reconnectAttempt;

    public TwelveDataClient(String apiKey) {
        this.apiKey = apiKey == null ? "" : apiKey.trim();
        http = new OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build();
    }

    public boolean hasApiKey() { return !apiKey.isEmpty() && !apiKey.startsWith("YOUR_"); }

    public void connectPrices(String symbols, PriceListener listener) {
        manuallyClosed = false;
        reconnectAttempt = 0;
        connectInternal(symbols, listener);
    }

    private void connectInternal(final String symbols, final PriceListener listener) {
        if (!hasApiKey()) { listener.onConnection(false, "API key missing"); return; }
        String url = "wss://ws.twelvedata.com/v1/quotes/price?apikey=" + URLEncoder.encode(apiKey, StandardCharsets.UTF_8);
        Request request = new Request.Builder().url(url).build();
        webSocket = http.newWebSocket(request, new WebSocketListener() {
            @Override public void onOpen(WebSocket ws, Response response) {
                reconnectAttempt = 0;
                ws.send("{\"action\":\"subscribe\",\"params\":{\"symbols\":\"" + symbols + "\"}}");
                main.post(() -> listener.onConnection(true, "LIVE STREAM CONNECTED"));
            }
            @Override public void onMessage(WebSocket ws, String text) {
                try {
                    JSONObject j = new JSONObject(text);
                    if (!j.has("price")) return;
                    String symbol = j.optString("symbol", "");
                    double price = j.optDouble("price", Double.NaN);
                    long ts = j.optLong("timestamp", System.currentTimeMillis()/1000L) * 1000L;
                    if (!Double.isNaN(price)) main.post(() -> listener.onPrice(symbol, price, ts));
                } catch (Exception ignored) { }
            }
            @Override public void onFailure(WebSocket ws, Throwable t, Response response) {
                main.post(() -> listener.onConnection(false, "LIVE STREAM LOST: " + safeMessage(t)));
                scheduleReconnect(symbols, listener);
            }
            @Override public void onClosed(WebSocket ws, int code, String reason) {
                main.post(() -> listener.onConnection(false, "STREAM CLOSED"));
                if (!manuallyClosed) scheduleReconnect(symbols, listener);
            }
        });
    }

    private void scheduleReconnect(String symbols, PriceListener listener) {
        if (manuallyClosed) return;
        int delay = Math.min(60000, 2000 * (1 << Math.min(reconnectAttempt++, 5)));
        main.postDelayed(() -> connectInternal(symbols, listener), delay);
    }

    public void loadCandles(String symbol, String interval, int outputSize, CandleListener listener) {
        if (!hasApiKey()) { listener.onError("API key missing"); return; }
        new Thread(() -> {
            try {
                String url = "https://api.twelvedata.com/time_series?symbol=" + URLEncoder.encode(symbol, StandardCharsets.UTF_8)
                        + "&interval=" + URLEncoder.encode(interval, StandardCharsets.UTF_8)
                        + "&outputsize=" + outputSize + "&apikey=" + URLEncoder.encode(apiKey, StandardCharsets.UTF_8);
                Request request = new Request.Builder().url(url).get().build();
                try (Response response = http.newCall(request).execute()) {
                    if (!response.isSuccessful()) throw new IOException("HTTP " + response.code());
                    String body = response.body() == null ? "" : response.body().string();
                    JSONObject root = new JSONObject(body);
                    if (root.has("code")) throw new IOException(root.optString("message", "API error"));
                    JSONArray values = root.optJSONArray("values");
                    if (values == null || values.length() < 60) throw new IOException("Not enough candle data returned");
                    List<Candle> list = new ArrayList<>();
                    for (int i=values.length()-1;i>=0;i--) {
                        JSONObject v=values.getJSONObject(i);
                        long ts=parseTime(v.optString("datetime",""));
                        list.add(new Candle(ts, v.getDouble("open"), v.getDouble("high"), v.getDouble("low"), v.getDouble("close")));
                    }
                    main.post(() -> listener.onCandles(Collections.unmodifiableList(list)));
                }
            } catch(Exception e) { main.post(() -> listener.onError(safeMessage(e))); }
        }).start();
    }

    private long parseTime(String s) {
        try { return java.time.OffsetDateTime.parse(s).toEpochSecond(); } catch(Exception ignored) {}
        try { return java.time.LocalDateTime.parse(s.replace(' ','T')).toEpochSecond(java.time.ZoneOffset.UTC); } catch(Exception ignored) {}
        return 0L;
    }

    private static String safeMessage(Throwable t) { return t == null || t.getMessage() == null ? "unknown error" : t.getMessage(); }

    public void close() { manuallyClosed=true; if(webSocket!=null) webSocket.close(1000,"app closed"); http.dispatcher().cancelAll(); }
}
